module.exports = {
  apps : [{
    name   : "app1",
    script : "./app.js"
  }]
}
